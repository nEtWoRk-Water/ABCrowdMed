package compute;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.lang.Exception;


class TimeCountProxyHandle implements InvocationHandler {
    Object proxied;
    public TimeCountProxyHandle(Object obj) {
        proxied = obj;
    }
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        long begin = System.currentTimeMillis();
        Object result = method.invoke(proxied, args);
        long end = System.currentTimeMillis();
        System.out.println(method.getName() + "耗时:" + (end - begin) + "ms");
        return result;
    }
}

class Ourscheme {
    //计算时间

    //初始化选取参数
        //从文件a.properties中读取参数初始化双线性群
    static Pairing pairing = PairingFactory.getPairing("a.properties");

         static Field Zr = pairing.getZr();
        static Field G1 = pairing.getG1();

       static Element u = G1.newRandomElement();
       static Element g = G1.newRandomElement();
       Element h = G1.newRandomElement();
       Element w = G1.newRandomElement();
       Element v = G1.newRandomElement();
       static Element mu = Zr.newRandomElement();
       static Element alpha = Zr.newRandomElement();
    Element beta = pairing.getZr().newRandomElement().getImmutable();

    //对称加密所需转换参数
    private byte[] hexStringToBytes(String hexString) {
        if (hexString.length() % 2 != 0) throw new IllegalArgumentException("hexString length not valid");
        int length = hexString.length() / 2;
        byte[] resultBytes = new byte[length];
        for (int index = 0; index < length; index++) {
            String result = hexString.substring(index * 2, index * 2 + 2);
            resultBytes[index] = Integer.valueOf(Integer.parseInt(result, 16)).byteValue();
        }
        return resultBytes;
    }
    private static String bytesToHexString(byte[] sources) {
        if (sources == null) return null;
        StringBuilder stringBuffer = new StringBuilder();
        for (byte source : sources) {
            String result = Integer.toHexString(source& 0xff);
            if (result.length() < 2) {
                result = "0" + result;
            }
            stringBuffer.append(result);
        }
        return stringBuffer.toString();
    }
    //对称加密算法
    private static byte[] encryptByAES(String content, String password) {
        // 算法,m和K
        try {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");// 创建AES的Key生产者
            kgen.init(128, new SecureRandom(password.getBytes()));// 利用用户密码作为随机数初始化出
            //加密没关系，SecureRandom是生成安全随机数序列，password.getBytes()是种子，只要种子相同，序列就一样，所以解密只要有password就行
            SecretKey secretKey = kgen.generateKey();// 根据用户密码，生成一个密钥
            byte[] enCodeFormat = secretKey.getEncoded();// 返回基本编码格式的密钥，如果此密钥不支持编码，则返回
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");// 转换为AES专用密钥
            Cipher cipher = Cipher.getInstance("AES");// 创建密码器
            byte[] byteContent = content.getBytes("utf-8");
            cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化为加密模式的密码器
            byte[] result = cipher.doFinal(byteContent);// 加密
            return result;
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    //对称解密算法
    private String decryptByAES(byte[] content, String password){
        // 算法,E和K
        try {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");// 创建AES的Key生产者
            kgen.init(128, new SecureRandom(password.getBytes()));
            SecretKey secretKey = kgen.generateKey();// 根据用户密码，生成一个密钥
            byte[] enCodeFormat = secretKey.getEncoded();// 返回基本编码格式的密钥
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");// 转换为AES专用密钥
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");// 创建密码器

            cipher.init(Cipher.DECRYPT_MODE, key);// 初始化为解密模式的密码器
            byte[] result = cipher.doFinal(content);
            return new String(result);// 明文
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static int random_number(){
        int number;
        number = new java.util.Random().nextInt(100)+1;
        return number;
    }
    static Element egg = pairing.pairing(g, g);
    static Element ab = alpha.duplicate().mul(mu);
    static Element C_i = egg.duplicate().powZn(ab);
    private static String hash_1(Element r) {
            String input = r.toString();
            MessageDigest md = null;
            try {
                md = MessageDigest.getInstance( "SHA-256" );
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
            String text = input;
            // Change this to UTF-16 if needed
            md.update( text.getBytes( StandardCharsets.UTF_8 ) );
            byte[] digest = md.digest();
            String hex = String.format( "%064x", new BigInteger( 1, digest ) );
            return hex;
    }
   private static String hash_2(Element r, String m) {
            String in = r.toString();
            String input = in + m;
            MessageDigest md = null;
            try {
                md = MessageDigest.getInstance( "SHA-256" );
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
            String text = input;
            // Change this to UTF-16 if needed
            md.update( text.getBytes( StandardCharsets.UTF_8 ) );
            byte[] digest = md.digest();
            String hex = String.format( "%064x", new BigInteger( 1, digest ) );
            return hex;
   }

    //在线加密阶段，输入消息和访问策略，输出全部加密密文，计算加密时间
    public void Compute(){
        System.out.println("-------------------离线加密阶段----------------------");
        int row = 50;
        int column = 50;
        long beginEE=System.currentTimeMillis();
        long sumEE=0;
        Element[] x_j = new Element[row];
        Element[] lambda_jj = new Element[row];
        Element[] t_j = new Element[row];
        //construct the lsss Matrix
        for (int j = 0; j < row; j++) {
            lambda_jj[j] = pairing.getZr().newRandomElement().getImmutable();
            x_j[j] = pairing.getZr().newRandomElement().getImmutable();
            t_j[j] = pairing.getZr().newRandomElement().getImmutable();
        }
        Element[] Cj11 = new Element[row];
        Element[] Cj12 = new Element[row];
        Element[] Cj2 = new Element[row];
        Element[] Cj3 = new Element[row];
        Element C0 = g.powZn(mu);
        for(int j=0; j<row; j++){
            Cj11[j] = w.powZn(lambda_jj[j]);
            Cj12[j] = v.powZn(t_j[j]);
            Cj2[j] = ((u.powZn(x_j[j]).mul(h)).powZn(t_j[j])).pow(BigInteger.valueOf(-1));
            Cj3[j] = g.powZn(t_j[j]);
        }
        Element C_i = egg.duplicate().powZn(ab);
        long endEE=System.currentTimeMillis();
        System.out.println("离线加密运行的时间为："+(endEE-beginEE)+"ms");

        System.out.println("-------------------在线加密阶段----------------------");
        //LsssPolicy
        //construct the lsss Matrix
        int[][] matrixA = new int[row][column];
        for (int i = 0; i <= row - 1; i++) {
            for (int j = 0; j <= column - 1; j++) {
                matrixA[i][j] = random_number();
            }
        }
        Element[][] elementLSSSMatrix = new Element[row][column];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                elementLSSSMatrix[i][j] = pairing.getZr().newElement(matrixA[i][j]).getImmutable();
            }
        }
        long beginE=System.currentTimeMillis();
        long sumE=0;
        //init vector v
        Element[] elementsV = new Element[column];//n个秘密分享
        elementsV[0] = mu.duplicate().getImmutable();
        for (int i = 1; i < elementsV.length; i++) {
            elementsV[i] = pairing.getZr().newRandomElement().getImmutable();//从Zp中选取v2，v3...vn
        }
        //secret share by matrix multiplication
        Element[] t_rhoi = new Element[row];
        //属性值
        for (int i=0; i<row; i++){
            t_rhoi[i] = pairing.getZr().newRandomElement().getImmutable();
        }
        Element[] elementsLambda = new Element[column];
        for (int i = 0; i < row; i++) {        //l个属性名
            elementsLambda[i] = pairing.getZr().newZeroElement().getImmutable();
            for (int j = 0; j < column; j++) {
                elementsLambda[i] = elementsLambda[i].add(elementLSSSMatrix[i][j].mulZn(elementsV[j])).getImmutable();//lambda i
            }
        }
        //Offline Encrypt
        //开始计算时间
        String m = "Jenny's scheme gaga good666";
        Element R = pairing.getZr().newRandomElement().getImmutable();
        Element C = R.mulZn(C_i) ;
        //计算Cj,45
        Element[] C_j4 = new Element[row];
        Element[] C_j5 = new Element[row];
        for(int j=0; j<row; j++){
            C_j4[j] = elementsLambda[j].sub(lambda_jj[j]) ;
            C_j5[j] = u.powZn(t_j[j].mulZn(x_j[j].sub(t_rhoi[j] )));
        }
        String K = hash_1 (R);//输入类型
        String tau = hash_2 (R,m);
        byte[] E = encryptByAES( m, K);
        //结束计算时间
        long endE=System.currentTimeMillis();
        System.out.println("在线加密运行的时间为："+(endE-beginE)+"ms");
        System.out.println("-------------------属性密钥生成阶段----------------------");
        Element[] r = new Element[row];
        Element[] Ki2 = new Element[row];
        Element[] Ki3 = new Element[row];
        Element r0 = pairing.getZr().newRandomElement().getImmutable();
        long beginKGen=System.currentTimeMillis();
        long sumKGen=0;
        Element K0 = g.powZn(alpha.mulZn(beta)).mul(w.powZn(r0));
        Element K1 = g.powZn(r0);
        for (int i=0; i<row; i++){
            r[i] = pairing.getZr().newRandomElement().getImmutable();
            Ki2[i] = g.powZn(r[i]);
            Ki3[i] = (u.powZn(t_rhoi[i]).mul(h)).powZn(r[i]).mul((v.powZn(r0)).pow(BigInteger.valueOf(-1)));
        }
        long endKGen=System.currentTimeMillis();
        System.out.println("属性密钥生成的时间为："+(endKGen-beginKGen)+"ms");
        Element[] AKK = new Element[row];
        Element[] Ci1 = new Element[row];
        Element[] Ci2 = new Element[row];
        for (int i=0; i<row; i++){
            AKK[i] = pairing.getZr().newRandomElement().getImmutable();
            Ci1[i] = Cj11[i].mul(Cj12[i]);
            Ci2[i] = Cj2[i].powZn(AKK[i]);
        }

        System.out.println("-------------------外包解密阶段----------------------");
        Element[] Ki22 = new Element[row];
        Element[] leijia = new Element[row];
        Element[] wi = new Element[row];
        Element[] one = new Element[row];
        Element[] two = new Element[row];
        Element[] three = new Element[row];
        Element[] four = new Element[row];
        long beginODec=System.currentTimeMillis();
        long sumODec=0;
        for (int i=0; i<row; i++){
            wi[i] = pairing.getZr().newRandomElement().getImmutable();
            AKK[i] = pairing.getZr().newRandomElement().getImmutable();
            Ki22[i] = Ki2[i].powZn(AKK[i].pow(BigInteger.valueOf(-1)));
            one[i] = pairing.pairing(Ci1[i], K1);
            two[i] = pairing.pairing(Ci2[i].mul(C_j5[i]), Ki22[i]);
            three[i] = pairing.pairing(Cj3[i], Ki3[i]);
        }
        for (int i=0; i<row-1; i++){
            leijia[0] = C_j4[0].mul(wi[0]);
            leijia[i+1] = leijia[i].add(C_j4[i+1].mul(wi[i+1]));
            four[0] = (one[0].mul(two[0]).mul(three[0])).powZn(wi[0]);
            four[i+1] = four[i].mul((one[i+1].mul(two[i+1]).mul(three[i+1])).powZn(wi[i+1]));
        }
        Element B = pairing.pairing(w.powZn(leijia[row-1]), K1);
        Element F = four[row-1];
        Element X = pairing.pairing(C0, K0);
        Element M = B.mul(F).mul(X.pow(BigInteger.valueOf(-1)));
        long endODec=System.currentTimeMillis();
        System.out.println("外包解密生成的时间为："+(endODec-beginODec)+"ms");

        System.out.println("-------------------解密阶段----------------------");
        //部分解密
        Element beta = pairing.getZr().newRandomElement().getImmutable();
        Element sk = beta;
        Element pk = g.duplicate().powZn(beta);
        Element egg = pairing.pairing(g, g);//egg
        Element alphamu = alpha.mul(mu);//alphamu
        Element alphamubeta = alphamu.mul(beta);//alphamubeta
        Element Y= egg.powZn(alphamubeta);
        Element mm = Y.pow(BigInteger.valueOf(-1));//部分解密结束
        //开始计算时间
        long beginD=System.currentTimeMillis();
        long sumD=0;
        Element D = beta.pow(BigInteger.valueOf(-1));
        Element RR = mm.powZn(D).mulZn(C);
        String KK = hash_1 (RR);//新的解密的密钥
        String decrypt_m = decryptByAES ( E , KK );
        String tautau = hash_2( RR, decrypt_m);
        if(tau == tautau){
           System.out.println("输出的解密消息="+decrypt_m);
        }
        long endD=System.currentTimeMillis();
        System.out.println("完全解密运行的时间为："+(endD-beginD)+"ms");


        //原始密文

        System.out.println("-------------------任务更新阶段----------------------");
        Element[] AK = new Element[row];
        Element mumu = pairing.getZr().newRandomElement().getImmutable();
        Element[] tjj = new Element[row];
        Element[] VV = new Element[column];
        Element[] Lambdaa = new Element[column];
        Element[] Cj111 = new Element[row];
        Element[] Cj122 = new Element[row];
        Element[] Cj22 = new Element[row];
        Element[] Cj33 = new Element[row];
        Element[] Cj44 = new Element[row];
        Element[] Cj55 = new Element[row];
        long beginUP=System.currentTimeMillis();
        long sumUP=0;
        Element CC = C.mulZn(egg.powZn(alpha.mulZn(mumu)));
        Element C00 = C0.mul(g.powZn(mumu));
        for (int j = 0; j < row; j++) {
            AK[j] = pairing.getZr().newRandomElement().getImmutable();
            tjj[j] = pairing.getZr().newRandomElement().getImmutable();
        }
        for (int i = 1; i < elementsV.length; i++) {
            VV[i] = pairing.getZr().newRandomElement().getImmutable();//从Zp中选取v2，v3...vn
        }
        VV[0] = mumu.duplicate().getImmutable();
        for (int i = 0; i < row; i++) {        //l个属性名
            Lambdaa[i] = pairing.getZr().newZeroElement().getImmutable();
            for (int j = 0; j < column; j++) {
                Lambdaa[i] = Lambdaa[i].add(elementLSSSMatrix[i][j].mulZn(VV[j])).getImmutable();//lambdaa i
            }
        }
        for(int j=0; j<row; j++){
            Cj111[j] = Cj11[j].mul(w.powZn(Lambdaa[j]));
            Cj122[j] = Cj12[j].powZn(tjj[j]);
            Cj22[j] = Cj2[j].powZn(tjj[j].mulZn(AK[j]));
            Cj33[j] = Cj3[j].powZn(tjj[j]);
            Cj44[j] = C_j4[j].sub(Lambdaa[j]);
            Cj55[j] = C_j5[j].powZn(tjj[j]);
        }
        long endUP=System.currentTimeMillis();
        System.out.println("任务更新的时间为："+(endUP-beginUP)+"ms");
    }

     public static void main(String[] args){
        Ourscheme ident = new Ourscheme();
        ident.Compute();

    }
}